module Main where

import MyLib

main :: IO ()
main = tui
